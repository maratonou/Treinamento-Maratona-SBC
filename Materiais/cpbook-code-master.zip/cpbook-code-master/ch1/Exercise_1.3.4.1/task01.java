import java.util.*;                              // Java code for task 1
class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    double d = sc.nextDouble();
    System.out.printf("%7.3f\n", d);             // Java has printf too!
  }
}
