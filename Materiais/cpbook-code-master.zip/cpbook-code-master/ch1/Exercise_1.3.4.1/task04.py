print(*sorted(set(input().split())), sep='\n')
