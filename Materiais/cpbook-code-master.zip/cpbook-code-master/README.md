# cpbook-code
CP4 Free Source Code Project (cpp/gnu++17, java/java8, py/python3, and ml/ocaml)

All code in this repo are mostly (reasonably good, hopefully :) implementation of many well-known data structures and algorithms,
so you are free to copy, adapt, use the code.

We will be thankful if you cite us (Steven & Felix Halim) when you use code in this repo.

This license is probably the most suitable: https://opensource.org/licenses/UPL
