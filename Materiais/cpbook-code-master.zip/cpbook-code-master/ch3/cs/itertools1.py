import itertools
print(list(itertools.permutations(range(4))))
